package com.javatodev.api.model;

public enum MemberStatus {
    ACTIVE, DEACTIVATED
}
